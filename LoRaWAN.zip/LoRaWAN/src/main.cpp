#include "LoRaWan_APP.h"
#include <Arduino.h>
// #include <RadioLib.h>
#include "TinyGPS++.h"
// #include <SoftwareSerial.h>

uint8_t devEui[] = {0x70, 0xB3, 0xD5, 0x7E, 0xD0, 0x05, 0xCB, 0x50};  
bool overTheAirActivation = true;
uint8_t appEui[] = {0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22};  // you should set whatever your TTN generates. TTN calls this the joinEUI, they are the same thing. 
uint8_t appKey[] = {0x75, 0xCC, 0x70, 0x78, 0xBF, 0xA6, 0xE8, 0x8D, 0x1A, 0x94, 0x95, 0xED, 0x68, 0x41, 0xF9, 0x54};  // you should set whatever your TTN generates  

//These are only used for ABP, for OTAA, these values are generated on the Nwk Server, you should not have to change these values
uint8_t nwkSKey[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
uint8_t appSKey[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
uint32_t devAddr =  (uint32_t)0x00000000;  

/*LoraWan channelsmask*/
uint16_t userChannelsMask[6]={ 0xFF00,0x0000,0x0000,0x0000,0x0000,0x0000 };

/*LoraWan region, select in arduino IDE tools*/
LoRaMacRegion_t loraWanRegion = ACTIVE_REGION;  // we define this as a user flag in the .ini file. 

/*LoraWan Class, Class A and Class C are supported*/
DeviceClass_t  loraWanClass = CLASS_A;

/*the application data transmission duty cycle.  value in [ms].*/
uint32_t appTxDutyCycle = 20000;

/*ADR enable*/
bool loraWanAdr = true;

// uint32_t license[4] = {};

/* Indicates if the node is sending confirmed or unconfirmed messages */
bool isTxConfirmed = true;

//GPS
TinyGPSPlus gps;

HardwareSerial GpioSerial(2);
/* Application port */
uint8_t appPort = 1;
/*!
* Number of trials to transmit the frame, if the LoRaMAC layer did not
* receive an acknowledgment. The MAC performs a datarate adaptation,
* according to the LoRaWAN Specification V1.0.2, chapter 18.4, according
* to the following table:
*
* Transmission nb | Data Rate
* ----------------|-----------
* 1 (first)       | DR
* 2               | DR
* 3               | max(DR-1,0)
* 4               | max(DR-1,0)
* 5               | max(DR-2,0)
* 6               | max(DR-2,0)
* 7               | max(DR-3,0)
* 8               | max(DR-3,0)
*
* Note, that if NbTrials is set to 1 or 2, the MAC will not decrease
* the datarate, in case the LoRaMAC layer did not receive an acknowledgment
*/
uint8_t confirmedNbTrials = 8;


/* Prepares the payload of the frame */
static void prepareTxFrame( uint8_t port, float longitude, float latitude )
{
	/*appData size is LORAWAN_APP_DATA_MAX_SIZE which is defined in "commissioning.h".
	*appDataSize max value is LORAWAN_APP_DATA_MAX_SIZE.
	*if enabled AT, don't modify LORAWAN_APP_DATA_MAX_SIZE, it may cause system hanging or failure.
	*if disabled AT, LORAWAN_APP_DATA_MAX_SIZE can be modified, the max value is reference to lorawan region and SF.
	*for example, if use REGION_CN470, 
	*the max value for different DR can be found in MaxPayloadOfDatarateCN470 refer to DataratesCN470 and BandwidthsCN470 in "RegionCN470.h".
	*/
    // This data can be changed, just make sure to change the datasize as well. 
	union{
		float f;
		uint32_t i;
	} longf = {.f = longitude};
	union{
		float f;
		uint32_t i;
	}latf = {.f = latitude};

	/*Structure
	* | 2 bytes | 4 bytes	    |	4 bytes		|
	---------------------------------------------------------------
	* |board #  | latitude 		| longitude     |
	*/

	Serial.printf("Board: %u | Long: %f (Long hex: %x) | Lat: %f (Lat Hex: %x)", 1, longitude, longf.i, latitude, latf.i);
	

    appDataSize = 10;
    appData[0] = devEui[6];
	appData[1] = devEui[7];
    appData[5] = (latf.i & 0xFF); //fisrt byte
    appData[4] = ((latf.i >> 8) & 0xFF); //second byte
    appData[3] = ((latf.i >> 16) & 0xFF); //third byte
	appData[2] = ((latf.i >> 24) & 0xFF); //fourth byte
	appData[9] = (longf.i & 0xFF); //fisrt byte
    appData[8] = ((longf.i >> 8) & 0xFF); //second byte
    appData[7] = ((longf.i >> 16) & 0xFF); //third byte
	appData[6] = ((longf.i >> 24) & 0xFF); //fourth byte


}



RTC_DATA_ATTR bool firstrun = true;

void setup() {
	Serial.begin(115200);
	GpioSerial.begin(9600, SERIAL_8N1, 21, 26); 
  	Mcu.begin();
  
	if(firstrun)
	{
		LoRaWAN.displayMcuInit();
		firstrun = false;
	}
		deviceState = DEVICE_STATE_INIT;
}

void loop()
{
	switch( deviceState )
	{
		case DEVICE_STATE_INIT:
		{
#if(LORAWAN_DEVEUI_AUTO)
			LoRaWAN.generateDeveuiByChipID();
#endif
			LoRaWAN.init(loraWanClass,loraWanRegion);
			break;
		}
		case DEVICE_STATE_JOIN:
		{
      LoRaWAN.displayJoining();
			LoRaWAN.join();
			if (deviceState == DEVICE_STATE_SEND){
			 	LoRaWAN.displayJoined();
			}
			break;
		}
		case DEVICE_STATE_SEND:
		{
			float longitude = 0;
			float latitude = 0;

      		LoRaWAN.displaySending();
			while( GpioSerial.available() > 0){
				gps.encode(GpioSerial.read());
				if(gps.location.isUpdated()){
					longitude = gps.location.lng();
					latitude =  gps.location.lat();
					Serial.print("Lat: ");
					Serial.println(latitude);
					Serial.print("Long: ");
					Serial.println( longitude);
					prepareTxFrame( appPort, longitude, latitude);
					LoRaWAN.send();
				}
				
			}		
			
			deviceState = DEVICE_STATE_CYCLE;
			break;
		}
		case DEVICE_STATE_CYCLE:
		{
			// Schedule next packet transmission
			txDutyCycleTime = appTxDutyCycle + randr( 0, APP_TX_DUTYCYCLE_RND );
			LoRaWAN.cycle(txDutyCycleTime);
			deviceState = DEVICE_STATE_SLEEP;
			break;
		}
		case DEVICE_STATE_SLEEP:
		{
      		LoRaWAN.displayAck();
			LoRaWAN.sleep(loraWanClass);
			break;
		}
		default:
		{
			deviceState = DEVICE_STATE_INIT;
			break;
		}
	}
}

